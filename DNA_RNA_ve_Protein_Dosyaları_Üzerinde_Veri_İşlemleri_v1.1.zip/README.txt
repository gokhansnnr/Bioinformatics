DNA, RNA ve Protein Verileriyle İşlemler v.1.1

Bu program ile DNA, RNA ve Protein dosyalarınıza hizalama yapabilirsiniz.Bu program verilerinizdeki gaplari silmektedir.
DNA ve RNA verilerinizle transkripsiyon veya reverse transkripsiyon işlemi yapabilirsiniz.
Ayrıca karşıt dizinin verilerini de elde edebilirsiniz.
DNA ve RNA dizilerindeki baz sayılarını ve yüzdelerini, pürin ve pirimidin baz sayılarını ve yüzdelerini görüntüleyebilirsiniz.

Protein verilerinizle gap silme işlemi yapıp görüntüleyebilirsiniz.

Bunların yanı sıra programla elde ettiğiniz verileri mevcut olan dosyanın üzerine yazabilir 
veya dosyayı farklı bir şekilde kaydedebilirsiniz.

FASTA dosyanızı FASTQ dosyasına, FASTQ dosyanızı da FASTA dosyasına dönüştürebilirsiniz. 
Dosyalarınızı .fasta .fastq .fa .fq .txt uzantılı bir şeklinde kaydedebilirsiniz.

NOT: Program multi-dosyalarda hata vermektedir. Tek veri içeren dosyalarda çalışmaktadır.
Ayrıca, dosyalarınızın uzantısı .fasta .fastq .fa .fq şeklinde olmalıdır.

Örnek dosyalar mevcuttur. İsterseniz o dosyalarda da işlemler yapabilirsiniz.

Programlayan : Gökhan Şener